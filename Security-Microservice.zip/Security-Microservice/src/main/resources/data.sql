insert into users (id, name, password)
values (1, 'John', 'John');
insert into users (id, name, password)
values (2, 'Jack', 'Jack');