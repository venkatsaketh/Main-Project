package com.cts.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
